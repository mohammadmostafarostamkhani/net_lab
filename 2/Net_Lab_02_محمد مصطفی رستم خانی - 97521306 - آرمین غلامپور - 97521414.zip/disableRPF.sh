	echo 0 > /proc/sys/net/ipv4/conf/all/rp_filter 
	echo 0 > /proc/sys/net/ipv4/conf/h4-eth0/rp_filter
	echo 0 > /proc/sys/net/ipv4/conf/h4-eth1/rp_filter
	echo 0 > /proc/sys/net/ipv4/conf/h4-eth2/rp_filter
